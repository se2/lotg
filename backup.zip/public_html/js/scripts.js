$(document).ready(function () {
	$('.banner').slick({
		slidesToShow: 1, 
		slideToScroll: 1,
		arrows: false,
		dots: false,
		infinite: true,
		slide: '.slide',
		autoplay: true,
		autoplaySpeed: 6000,
	});
	
});